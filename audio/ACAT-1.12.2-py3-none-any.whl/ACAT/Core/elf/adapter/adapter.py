############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its
# subsidiaries. All rights reserved.
#
############################################################################
import logging
import os
from tempfile import NamedTemporaryFile
from abc import ABC, abstractmethod

import kalelfreader_lib_wrappers as elfreaderlib
from ACAT.Core import Arch
from ACAT.Core.compression import is_zip, extract
from ACAT.Core.elf.adapter.objects import SectionHeaderInfoItem

from ACAT.Core import CoreUtils as cu

logger = logging.getLogger(__name__)


def get_elfreader(elf_filename):
    """Returns the object of the elf reader.

    Args:
        elf_filename (str): Full path to the elf filename.

    Returns:
        obj: This object can be used as a context manager.
    """
    try:
        return KalPythonToolAdaptor(elf_filename)
    except elfreaderlib.KerErrorCouldntOpenFile:
        try:
            return PyElfToolAdaptor(elf_filename)
        except ImportError:
            raise RuntimeError(
                "Optional dependency `pyelftools` needs to be installed."
            )


class BaseAdaptor(ABC):
    @property
    @abstractmethod
    def modify_time(self):
        """Gets the modified time of the ELF file."""

    @property
    @abstractmethod
    def version(self):
        """Gets the version of the ELF parser."""

    @property
    @abstractmethod
    def debug_strings(self):
        """Gets debug strings in the ELF file."""

    @property
    @abstractmethod
    def constants(self):
        """Gets the constants."""

    @property
    @abstractmethod
    def pm(self):
        """Gets the PM."""

    @property
    @abstractmethod
    def variables(self):
        """Gets the variables."""

    @property
    @abstractmethod
    def labels(self):
        """Gets the labels."""

    @property
    @abstractmethod
    def pm_data(self):
        """Gets the PM data."""

    @property
    @abstractmethod
    def dm_data(self):
        """Gets the DM data."""

    @property
    @abstractmethod
    def dm_word_width(self):
        """Gets the DM word width"""

    @property
    @abstractmethod
    def types(self):
        """Gets the types."""

    @property
    @abstractmethod
    def enums(self):
        """Gets the enums."""

    @property
    @abstractmethod
    def section_headers(self):
        """Gets the section headers."""


class KalPythonToolAdaptor(BaseAdaptor):
    """Kal Python Tool (kalaccess) adapter."""
    def __init__(self, filename):
        self._filename = filename
        self._elf_path = None

        logger.info("Loading %s", filename)
        self._ker = elfreaderlib.Ker()

        if is_zip(filename):
            with NamedTemporaryFile(delete=False) as temp_file:
                temp_file.write(extract(filename))
                self._elf_path = temp_file.name
        else:
            self._elf_path = filename

        self._ker.open_file(self._elf_path, ["debug_strings"])
        self._is_open = True

    @property
    def modify_time(self):
        """Gets the modified time of the ELF file."""
        return os.path.getmtime(self._elf_path)

    @property
    def version(self):
        """Gets the version of the ELF parser."""
        return self._ker.get_version()

    @property
    def debug_strings(self):
        """Gets debug strings in the ELF file."""
        try:
            # returns a tuple of the form
            # (bit_width, byte_addressing = 1, start_addr, num_bytes, data)
            debug_strings_data = self._ker.get_named_non_allocable_section_data("debug_strings")

        except BaseException:  # pylint: disable=broad-exception
            # this should be KerErrorSectionDataNotFound but we don't import
            # all the kalelfreader just for this error.
            logger.info("No debug strings in the build.")
            return

        if debug_strings_data is None:
            # No debug strings in the build, no need to read them.
            return

        string_in_progress = ""
        # Start of the Debug region.
        string_start_addr = Arch.dRegions['DEBUG'][0]
        debug_strings = {}

        # counts the number of characters in a string in order to obtain
        # the start address of the next string.
        no_of_addr_units = 0
        debug_values = debug_strings_data[4]
        for entry in debug_values:
            string = cu.get_string_from_word(Arch.addr_per_word, entry)
            for char in string:
                if char != '\0':
                    string_in_progress += char
                    no_of_addr_units += 1
                else:
                    debug_strings[string_start_addr] = string_in_progress
                    # Next address is start of next string
                    string_start_addr += no_of_addr_units + 1
                    string_in_progress = ""
                    no_of_addr_units = 0

        return debug_strings

    @property
    def constants(self):
        """Gets the constants."""
        return self._ker.get_constants()

    @property
    def pm(self):
        """Gets the PM."""
        return self._ker.get_statements()

    @property
    def variables(self):
        """Gets the variables."""
        return self._ker.get_variables()

    @property
    def labels(self):
        """Gets the labels."""
        return self._ker.get_labels()

    @property
    def pm_data(self):
        """Gets the PM Data."""
        return self._ker.get_pm_data()

    @property
    def dm_data(self):
        """Gets the DM data."""
        return self._ker.get_dm_data()

    @property
    def dm_word_width(self):
        """Gets the DM word width"""
        return self._ker.get_architecture()[2]

    @property
    def types(self):
        """Gets the types."""
        return self._ker.get_types()

    @property
    def enums(self):
        """Gets the enums."""
        return self._ker.get_enums()

    @property
    def section_headers(self):
        """Gets the section headers."""
        section_headers = {}
        for header_name, info in self._ker.get_elf_section_headers().items():
            section_headers[header_name] = SectionHeaderInfoItem(
                header_name,
                info.address,
                info.num_bytes,
                info.type,
                info.flags
            )

        return section_headers

    def __enter__(self):
        self._is_open = False
        return self

    def __exit__(self, *exc):
        if self._is_open:
            self._ker.close_file()

        if self._elf_path != self._filename:
            # Remove the zip file.
            os.unlink(self._elf_path)
