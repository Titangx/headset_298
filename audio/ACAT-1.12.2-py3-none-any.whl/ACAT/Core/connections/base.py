############################################################################
# CONFIDENTIAL
#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its subsidiaries. All
# rights reserved.
#
############################################################################
"""Connection Base.

Create a base connection class for derived objects.
"""
from abc import ABC, abstractclassmethod


def get_connection(transport, processor, pydbg=False):
    """Get the connection based on the given transport.

    Args:
        transport (str): Transport string.
        processor (int): Processor number. This can be either 0 or 1.
        pydbg (bool): Use Pydbg for the connection.

    Returns:
        A connection object.
    """
    if pydbg:
        from ACAT.Core.connections.pydbg import PydbgConnection
        return PydbgConnection(transport, processor)

    # Import the kalaccess when needed. Moving this at the top level import
    # cause failure as the path needs manipulation and it's being done
    # in argument parser. This way, we make sure the path manipulation is
    # already being done.
    from ACAT.Core.connections.kalaccess import KalaccessConnection
    return KalaccessConnection(transport, processor)


class Connection(ABC):
    """Connection abstraction object to the live chip.

    Args:
        transport (str): Transport string.
        processor (int): Processor number. This can be either 0 or 1.
    """
    ADDRESS_PER_WORD = 4

    def __init__(self, transport, processor):
        self._dm = None
        self._pm = None

        self._processor = processor
        self._transport = transport

    @abstractclassmethod
    def reconnect(self):
        """Reconnect the chip."""

    @abstractclassmethod
    def get_register(self, name):
        """Get the value of a register.

        Args:
            name (str): Register name.

        Returns:
            Value of the given register.
        """

    @abstractclassmethod
    def get_register_names(self):
        """Get all the register names.

        Returns:
            A list of register names.
        """

    @abstractclassmethod
    def read_dm(self, start, end=None):
        """Read from the Data Memory.

        Args:
            start (int): Starting address to read.
            end (int): Ending address to read.
        """

    @abstractclassmethod
    def read_pm(self, start, end=None):
        """Read from the Program Memory.

        Args:
            start (int): Starting address to read.
            end (int): Ending address to read.
        """

    @abstractclassmethod
    def set_dm(self, address, value):
        """Setting a value to a Data Memory

        Args:
            address (int): The address to write.
            value (int): The value to write in the given address.
        """
