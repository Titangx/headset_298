#
# Copyright (c) 2021 Qualcomm Technologies, Inc. and/or its
# subsidiaries.  All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""AuraPlus1.1 Chip interface."""
import logging

from ksp.lib.chips.chipbase import GenericChip
from ksp.lib.firmware.kymera_qcc514x import KymeraQCC514x
from ksp.lib.logger import method_logger

logger = logging.getLogger(__name__)


class QCC514x(GenericChip):
    """KSP Emulator for Aura Plus Chip type.

    Full version:      0x114B
    """
    @method_logger(logger)
    def __init__(self, device):
        super().__init__(device)

        _, apps1 = (
            device.chip.apps_subsystem.p0,
            device.chip.apps_subsystem.p1
        )
        self._firmware = KymeraQCC514x(apps1)
