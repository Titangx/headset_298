#
# Copyright (c) 2020 Qualcomm Technologies, Inc. and/or its subsidiaries.
# All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""Boilerplate for various chip interfaces."""
import logging
import threading

import ksp.lib.namespace as ns
from ksp.lib.exceptions import OperatorError, FirmwareError, CommandError
from ksp.lib.logger import method_logger
from ksp.lib.firmware.operator.ksp_operator_manager import KSPOperatorManager
from ksp.lib.firmware.kymera import Kymera
from ksp.lib.transport import get_transport, is_testtunnel
from ksp.lib.transport.testtunnel import TTTransport

logger = logging.getLogger(__name__)
TRB_NUMBER_OF_TRANSACTIONS = 100


# The number of instance attributes related to `GenericChip` class is
# expected and necessary for a boiler plate.
# pylint: disable=too-many-instance-attributes
class GenericChip(object):
    """A boilerplate class for chips implementations.

    Args:
        device (object): Device instance object comes from pydbg library.
    """
    IS_EDKCS = True

    @method_logger(logger)
    def __init__(self, device):
        self._device = device

        _, self._apps1 = (
            device.chip.apps_subsystem.p0,
            device.chip.apps_subsystem.p1
        )
        self._firmware = Kymera(self._apps1)

        self._read_stop_event = threading.Event()
        self._read_data_process = None

        self._op_manager = None
        self._ksp_operator = None

        self._transport = None
        self._byte_swap = False

    @property
    def byte_swap(self):
        """Determine the received data from transport is byte swapped."""
        return self._byte_swap

    @property
    def is_transport_testtunnel(self):
        """Determine whether the transport's data is byte swapped."""
        return is_testtunnel(self._device)

    @method_logger(logger)
    def start_probe(self, output_filename, config):
        """Starts the probe based on the given configurations.

        Args:
            output_filename (str): A filename that output which KSP will
                write into it.
            config (dict): A dictionary configuration which the keys are
                exactly the same as KymeraStreamProbeCLI's configuration.

        Raises:
            CommandError: When there is a probe running.
        """
        self._reset()

        self._init_operator(config)
        self._init_transport()
        self._start_transport(output_filename)

        try:
            self._op_manager.start()

        except OperatorError:
            # Communication to the KSP cap is failed. Stop the reader.
            self._stop_transport()
            raise

    @method_logger(logger)
    def stop_probe(self):
        """Stops the running probe.

        Raises:
            CommandError: When the probe is already stopped.
        """
        try:
            self._stop_transport()
            self._stop_ksp_op()

        except CommandError:
            raise CommandError("The probe is already stopped.")
        except FirmwareError as error:
            raise CommandError(
                "Cannot stop the probe gracefully. The application may need "
                " to restart. Error: {}".format(error)
            )

        finally:
            self._reset()

    @method_logger(logger)
    def start_op(self, config):
        """Configure and start the KSP operator.

        Args:
            config (dict): Stream configurations.
        Raises:
            CommandError: When the operator is already running.
            CommandError: Something goes wrong when configuring the
                operator.
        """
        if self._op_manager:
            raise CommandError("KSP is already being configured.")

        try:
            self._init_operator(config)
            self._op_manager.start()

        except CommandError as error:
            logger.warning(error)
            raise CommandError("Unable to start the KSP operator.")

        logger.info("KSP operator is successfully being setup and running.")

    @method_logger(logger)
    def stop_op(self):
        """Stop and unload the ksp downloadable operator.

        Raises:
            CommandError: Something goes wrong when stopping the operator.
        """
        try:
            self._op_manager.stop()
            self._op_manager = None

        except FirmwareError as error:
            logger.warning(error)
            raise CommandError("Unable to stop the KSP operator")

    @method_logger(logger)
    def start_reader(self, output_filename):
        """Start the transport link to save the data flowing in.

        Args:
            output_filename (str): The filename and the location of where
                the received data should be saved.
        """
        self._init_transport()
        self._start_transport(output_filename)

    @method_logger(logger)
    def stop_reader(self):
        """Stop the transport link to the chip."""
        try:
            self._stop_transport()

        except CommandError:
            raise CommandError("The probe is already stopped.")

    @method_logger(logger)
    def _is_op_running(self):
        """Checks whether the KSP operator is running.

        Returns:
            bool: True if the operator is running, False otherwise.
        """
        if self._op_manager and self._op_manager.is_running():
            return True

        return False

    @method_logger(logger)
    def _is_capture_running(self):
        """Checks whether the capture thread is running.

        Returns:
            bool: True if the capture thread is running, False otherwise.
        """
        if self._read_data_process and self._read_data_process.is_alive():
            return True

        return False

    @method_logger(logger)
    def _stop_ksp_op(self):
        if self._op_manager is None:
            raise CommandError("KSP operator is not running.")

        self._op_manager.stop()

        # By deleting the Operator Manager, the downloadable will be unloaded.
        del self._op_manager
        self._op_manager = None

    @method_logger(logger)
    def _reset(self):
        if self._is_capture_running():
            self._stop_transport()

        if self._is_op_running():
            self._stop_ksp_op()

        self._transport = None

    @method_logger(logger)
    def _init_operator(self, config):
        try:
            self._op_manager = KSPOperatorManager(
                self._firmware,
                edkcs=self.IS_EDKCS,
                builtin_cap=config[ns.USE_BUILTIN_CAP]
            )
        except FirmwareError as error:
            raise CommandError(error)

        self._op_manager.config(config[ns.STREAMS])

    @method_logger(logger)
    def _init_transport(self):
        p0_op_id = self._op_manager.operator_ids.get(ns.P0_OP_ID)

        self._transport = get_transport(
            device=self._device,
            apps1=self._apps1,
            firmware=self._firmware,
            p0_op_id=p0_op_id,
            verbose=True,
        )

        # Test Tunnel data is byte swapped.
        self._byte_swap = isinstance(self._transport, TTTransport)

    @method_logger(logger)
    def _start_transport(self, output_filename):
        self._read_data_process = threading.Thread(
            target=self._transport.start,
            args=(
                output_filename,
                self._read_stop_event,
            )
        )

        self._read_data_process.start()

    @method_logger(logger)
    def _stop_transport(self):
        if self._transport is None:
            raise CommandError("Transport is not running.")

        if self._read_data_process:
            self._read_stop_event.set()
            self._read_data_process.join()

            self._read_stop_event.clear()
            self._read_data_process = None

        self._transport.stop()
